"""EasyTour utility package."""
