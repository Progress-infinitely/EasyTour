"""EasyTour processor package."""
